** Important Files **
+ input file
- output file

1. request.php: 									convert API from wit.ai return to Bot
 + keys.txt (important)								contains keys used by Bot
 - mess_log.api										log the messages sent by Bot to Wit.ai 
 - data_log.api										log the keys api sent by Wit.ai to Bot
 
2. messages.php: 									api log the messages
 - mess_to_admin_log.txt							log the messages sent by user to admin
 
3. /Users/add/addUser.php:							api add user information to database

4. /Users/update/updateUser.php:					api update user information to database

5. /Users/download_excel/index.php					page download user login information records (excel file)

6. /Users/lib/connection.php						database connection configuration