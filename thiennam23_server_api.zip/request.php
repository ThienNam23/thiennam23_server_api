<?php
/**
 * Verify
 */
  $pass = $_REQUEST['pass'];
  if ($pass !== "HyhM5Aj3") die();
  
/**
 * Send request to Wit.ai
 */

 // Encode payload from BotStar
$raw = json_decode(file_get_contents('php://input'), 1);
$q = urlencode($raw);

$file = fopen("mess_log.api", "a");
fwrite($file, $raw . "\r\n");
fclose($file);

// Connect to Wit.ai
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://api.wit.ai/message?v=20201104&q=" . $q);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');

$headers = array();
$headers[] = 'Authorization: Bearer YF4KP3OWJJU2TVGLLRFBZRXGAIMANOBB';
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

$raw = curl_exec($ch); // get response from wit.ai

// if error
if (curl_errno($ch)) {
    echo 'Error:' . curl_error($ch);
}

curl_close($ch); // close connection

//-----------------------------------------------------------------------------//

/**
 * BotStar variables
 */

// Keys
$keys = ["question_type", "target", "target_trait", "action", "status", "programs", "certificate", "majors", "student", "objects", "place"];
// Entities
$result = array(
  "question_type" => [],
  "target" => [],
  "target_trait" => [],
  "action" => [],
  "status" => [],
  "programs" => [],
  "certificate" => [],
  "majors" => [],
  "student" => [],
  "objects" => [],
  "place" => []
);
//-----------------------------------------------------------------------------//

/**
 * Analyze data from Wit.ai
 */
$json = json_decode($raw, true);

// getting entities
foreach ($json['entities'] as $entities) {
    foreach ($entities as $entity) {
      if (empty($entity['suggested']))
        $result[$entity['name']][$entity['value']] = $entity['confidence'];
    }
  }

// getting traits
foreach ($json['traits'] as $key => $value) {
  $result[$key][$value[0]['value']] = $value[0]['confidence'];
}

//echo $keys[count($keys) - 1];
for ($i = count($keys) - 1; $i > -1 && empty($result[$keys[$i]]); $i--) {
  $result[$keys[$i]]['del'] = 0;
}
for ($i = 0; $i < 11; $i++) {
  if (!count($result[$keys[$i]])) {
    $result[$keys[$i]]['null'] = 0;
  }
}

//-----------------------------------------------------------------------------//
/**
 * get text form key
 */
function get_string($arr, $trait = true)
{
  $str = "";
  if (!$trait) {
    $str = "/";
  }
  foreach ($arr as $key => $value) {
    if ($key === "del" || $key === "null") {
      return $key;
    }
    $str .= $key;
    if (!$trait) {
      $str .= "/";
    }
  }
  return $str;
}

//-----------------------------------------------------------------------------//

/**
 * Check if result exists
 */
function exist($key)
{
  $file = fopen("keys.txt", "r");
  $str = fread($file, filesize("keys.txt"));
  $str = preg_replace("/\r|\n/", "", $str);
  //echo $key;
  return strpos($str, $key);
}

function create_key($result)
{
  global $keys;
  $str = "~";
  for ($i = 0; $i < 11; $i++) {
    $sub_str = get_string($result[$keys[$i]], $i < 5);
    $str .= $sub_str . ",";
  }
  $str = str_replace("/,", ',', $str);
  $str = str_replace(",/", ',', $str);
  $str = str_replace("null", '', $str);
  $str = str_replace("del", '', $str);
  return substr($str, 0, -1) . "~";
}

//-----------------------------------------------------------------------------//

/**
 * Send data to BotStar
 */
$str = "";
if (exist(create_key($result)) === false) {
  $str = "{
        \"actions\": [
          {
            \"type\": \"set_variable\",
            \"data\": {
              \"question_type\" : \"del\"
            }
          }
        ]
      }";
} else {
  $str = "{
        \"actions\": [
          {
            \"type\": \"set_variable\",
            \"data\": {
              \"question_type\" : \"" . get_string($result[$keys[0]]) . "\",
              \"target\" : \"" . get_string($result[$keys[1]]) . "\",
              \"target_trait\" : \"" . get_string($result[$keys[2]]) . "\",
              \"action\" : \"" . get_string($result[$keys[3]]) . "\",
              \"status\" : \"" . get_string($result[$keys[4]]) . "\",
              \"programs\" : \"" . get_string($result[$keys[5]], false) . "\",
              \"certificate\" : \"" . get_string($result[$keys[6]], false) . "\",
              \"majors\" : \"" . get_string($result[$keys[7]], false) . "\",
              \"student\" : \"" . get_string($result[$keys[8]], false) . "\",
              \"objects\" : \"" . get_string($result[$keys[9]], false) . "\",
              \"place\" : \"" . get_string($result[$keys[10]], false) . "\"
            }
          }
        ]
      }";
}
echo $str;

$file = fopen("data_log.api", "a");
fwrite($file, create_key($result) . "\r\n");
fclose($file);