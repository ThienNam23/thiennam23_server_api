<?php
function download($extension)
{
    date_default_timezone_set('Asia/Bangkok');
    //Clear the cache
    clearstatcache();

    // Rename file
    $original_filename = "export." . $extension;
    $new_filename = "Chatbot_users_" . date("dmy_His") . "." . $extension;

    //Define header information
    header('Content-Description: File Transfer');
    header('Content-Type: application/octet-stream');
    header('Content-Disposition: attachment; filename="' . $new_filename . '"');
    header("Content-Length: " . filesize($original_filename));
    header('Pragma: public');

    //Clear system output buffer
    flush();

    // upload the file to the user and quit
    readfile($original_filename);

    //Terminate from the script
    exit();
}

if (isset($_GET['xls-btn'])) {
    download("xls");
} elseif (isset($_GET['xlsx-btn'])) {
    download("xlsx");
} else {
    die();
}
