<?php
    require_once 'export.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ThienNam Dowload Page</title>
    <style>
        body {
            text-align: center;
        }
        .btn-download {
            width: 300px;
            height: 40px;
            font-size: 22px;
            font-weight: bold;
            background-color: lightgreen;
            border: 1px solid green;
            outline-style: none;
            cursor: pointer;
            border-radius: 15px;
        }
    </style>
</head>
<body>
    <h1>Excel File Download Page</h1>
    <hr width="50%">
    <form action="download_excel.php" method="get">
        Hiện tại đang có <?php echo count($user_data) - 1; ?> bản ghi. Vui lòng chọn định đạng tệp tin <br><br>
        <input class="btn-download" type="submit" name="xls-btn" value=".xls">
        <input class="btn-download" type="submit" name="xlsx-btn" value=".xlsx">
    </form>
</body>
</html>
