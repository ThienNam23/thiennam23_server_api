<?php

/**
 * PHPExcel
 *
 * Copyright (c) 2006 - 2015 PHPExcel
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 *
 * @category   PHPExcel
 * @package    PHPExcel
 * @copyright  Copyright (c) 2006 - 2015 PHPExcel (http://www.codeplex.com/PHPExcel)
 * @license    http://www.gnu.org/licenses/old-licenses/lgpl-2.1.txt	LGPL
 * @version    ##VERSION##, ##DATE##
 */

/** Error reporting */
error_reporting(E_ALL);
ini_set('display_errors', TRUE);
ini_set('display_startup_errors', TRUE);
date_default_timezone_set('Asia/Bangkok');

define('EOL', (PHP_SAPI == 'cli') ? PHP_EOL : "\r\n");
/** Include PHPExcel */
require_once '../PHPExcel-1.8/Classes/PHPExcel.php';

/** Write Export Log */
$export_log = fopen("ExportLog.txt", "w");
function write_log($str)
{
    global $export_log;
    fwrite($export_log, date('H:i:s') . ": " . $str . EOL);
}
// Create new PHPExcel object
write_log("Create new PHPExcel object");
$objPHPExcel = new PHPExcel();

// Set document properties
write_log("Set document properties");
$objPHPExcel->getProperties()->setCreator("ChatBot23")
    ->setLastModifiedBy("ChatBot23")
    ->setTitle("PHPExcel Test Document")
    ->setSubject("PHPExcel Test Document")
    ->setDescription("Test document for PHPExcel, generated using PHP classes.")
    ->setKeywords("office PHPExcel php")
    ->setCategory("Test result file");

// Retrieve Data
$_REQUEST['p'] = "libTN23";
require_once("../lib/getUserController.php");
$user_data = getUser();
// Add Header
write_log("Add data");
//$objPHPExcel->getActiveSheet()->getRowDimension(8)->setRowHeight(-1);
$objPHPExcel->getActiveSheet()->getColumnDimension("B")->setWidth(25);
$objPHPExcel->getActiveSheet()->getColumnDimension("C")->setWidth(15);
$objPHPExcel->getActiveSheet()->getColumnDimension("D")->setWidth(38);
foreach ($user_data as $key => $value) {
    $objPHPExcel->setActiveSheetIndex(0)
        ->setCellValue("A" . ($key + 1), $user_data[$key][0])
        ->setCellValue("B" . ($key + 1), $user_data[$key][1])
        ->setCellValue("C" . ($key + 1), $user_data[$key][2])
        ->setCellValue("D" . ($key + 1), $user_data[$key][3]);
}

// Rename worksheet
write_log("Rename worksheet");
$objPHPExcel->getActiveSheet()->setTitle('Users');


// Set active sheet index to the first sheet, so Excel opens this as the first sheet
$objPHPExcel->setActiveSheetIndex(0);


// Save Excel 2007 file
write_log("Write to Excel2007 format");
$callStartTime = microtime(true);

$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
$objWriter->save(str_replace('.php', '.xlsx', __FILE__));
$callEndTime = microtime(true);
$callTime = $callEndTime - $callStartTime;

write_log("File written to " . str_replace('.php', '.xlsx', pathinfo(__FILE__, PATHINFO_BASENAME)));
write_log("Call time to write Workbook was " . sprintf('%.4f', $callTime) . " seconds");
// Echo memory usage
write_log("Current memory usage: " . (memory_get_usage(true) / 1024 / 1024) . " MB");


// Save Excel 95 file
write_log("Write to Excel5 format");
$callStartTime = microtime(true);

$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');
$objWriter->save(str_replace('.php', '.xls', __FILE__));
$callEndTime = microtime(true);
$callTime = $callEndTime - $callStartTime;

write_log("File written to " . str_replace('.php', '.xls', pathinfo(__FILE__, PATHINFO_BASENAME)));
write_log("Call time to write Workbook was " . sprintf('%.4f', $callTime) . " seconds");
// Echo memory usage
write_log("Current memory usage: " . (memory_get_usage(true) / 1024 / 1024) . " MB");


// Echo memory peak usage
write_log("Peak memory usage: " . (memory_get_peak_usage(true) / 1024 / 1024) . " MB");

// Echo done
write_log("Done writing files");
write_log("Files have been created in " . getcwd());
