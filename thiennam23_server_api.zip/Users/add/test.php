<?php
echo '{ "actions": [ { "type": "set_variable", "data": { "userID" : "ub23000012" } } ] }';