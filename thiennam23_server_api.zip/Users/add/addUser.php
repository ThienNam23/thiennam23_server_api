<?php
//if (!(isset($_REQUEST['pass']) && $_REQUEST['p'] == "HyhM5Aj3")) die();

$user = json_decode(file_get_contents('php://input'), 1);
if ($user['pass'] == "HyhM5Aj3") {
    $_REQUEST['p'] = "libTN23";
    require_once("../lib/addUserController.php");
    $file = fopen("Log.txt", "w");
    $str = addUser($user);
    fwrite($file, $str);
    fclose($file);
    echo $str;
}
else {
    die();
}