<?php
if (!(isset($_REQUEST['p']) && $_REQUEST['p'] == "libTN23")) die();
function retrieve_data($result)
{
    $arr = [["STT", "Name", "Phone Number", "Email"]];
    while($row = $result->fetch_assoc()) {
        array_push($arr, [$row["STT"], $row["name"], $row["phone_number"], $row["email"]]);
      }
    return $arr;
}

function getUser() {
    require_once("connection.php");

    if (!$conn->connect_error) {

        $sql = "SELECT * FROM users_botchat WHERE 1";
        $result = $conn->query($sql);

        $conn->close();

        return retrieve_data($result);
    }
}