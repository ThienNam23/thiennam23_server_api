<?php

if (isset($_REQUEST['p']) && $_REQUEST['p'] == "libTN23") {
    $db_servername = "localhost"; // ex: localhost
    $db_name = "id14838996_main_db"; // db name
    $db_username = "id14838996_myweb2303"; // db user name
    $db_password = "EndFiLe2303:)"; // db user password

    error_reporting(0);
    // Create connection
    $conn = new mysqli($db_servername, $db_username, $db_password, $db_name);

    // Check connection
    if ($conn->connect_error) {
        echo "<p class='error-mess'>*Connection failed: " . $conn->connect_error . "</p>";
    }
} else {
    die();
}
