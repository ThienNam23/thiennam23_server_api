<?php
//if (!(isset($_REQUEST['p']) && $_REQUEST['p'] == "libTN23")) die();
function genNewID() {
    $filename = "../number_users.txt";
    $number = trim(file_get_contents($filename));
    $number = $number + 1;
    $id = "000000" . $number;
    $id = substr($id, strlen($id) - 6);

    $file = fopen($filename, "w");
    fwrite($file, $number);
    fclose($file);
    return "ub23" . $id;
}
function addUser($user)
{
    require_once("connection.php");
    $id = $user['id'];
    $name = $user['name'];
    $phone_number = $user['phone_number'];
    $email = $user['email'];
    $str = "{
                \"actions\": [
                {
                    \"type\": \"set_variable\",
                    \"data\": {
                    \"temp\" : \"existindb\"
                    }
                }
                ]
            }";

    // Check if user exist
    $sql = "SELECT * FROM users_chatbot WHERE id='$id'";
    $result = $conn->query($sql);
    if (!$result->num_rows) {
        // if not exist do INSERT 
        // Gen new ID here
        $id = genNewID();
        $sql = "INSERT INTO users_chatbot(id, name, phone_number, email) VALUES ('$id', '$name', '$phone_number', '$email')";
        if (mysqli_query($conn, $sql)) {
            $str = "{
                \"actions\": [
                {
                    \"type\": \"set_variable\",
                    \"data\": {
                    \"userID\" : \"" . $id . "\"
                    }
                }
                ]
            }";
          } else {
            $file = fopen("Error_Log.txt", "w");
            fwrite($file, "Error: " . $sql . "<br>" . mysqli_error($conn));
            fclose($file);
            //return "Error: " . $sql . "<br>" . mysqli_error($conn);
          }
        mysqli_close($conn);
    }
    
    return $str;
}