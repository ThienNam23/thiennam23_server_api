<?php
//if (!(isset($_REQUEST['pass']) && $_REQUEST['p'] == "HyhM5Aj3")) die();

date_default_timezone_set('Asia/Bangkok');
$user = json_decode(file_get_contents('php://input'), 1);
//$user = json_decode($user, 1);
if ($user['pass'] == "HyhM5Aj3") {
    $_REQUEST['p'] = "libTN23";
    require_once("../lib/updateUserController.php");
    
    $str = updateUser($user);
    $file = fopen("Log.txt", "a");
    fwrite($file,"[" . date("d/m/y H:i:s") . "] " . $str . "\r\n");
    fclose($file);
    echo $str;
}
else {
    die();
}