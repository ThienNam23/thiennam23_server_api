<?php
date_default_timezone_set('Asia/Bangkok');
$pass = $_REQUEST['pass'];
if ($pass !== 'LDzQZN6CecET2qGj')
    die();

$my_file = fopen('mess_to_admin_log.txt', 'a');
$raw = json_decode(file_get_contents('php://input'), 1);
//$raw = "Thien Nam~Hello";
$mess = explode('~', $raw);
fwrite($my_file,"[" . date("d/m/y H:i:s") . "] " . $mess[0] . ': ' . $mess[1] . "\r\n");
fclose($my_file);
